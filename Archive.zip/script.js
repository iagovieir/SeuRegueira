function Open(){
    var divPoupup = document.getElementById("popup")
    divPoupup.style.display = "flex";
}
function Close(){
    var divPoupup = document.getElementById("popup")
    divPoupup.style.display = "none";
}

function instagram(){
    window.location.href = 'https://www.instagram.com/seuregueira/'
}
function twitter(){
    window.location.href = 'https://twitter.com/seuregueirazn'
}
function facebook(){
    window.location.href = 'https://www.facebook.com/seuregueira'
}
function googlemaps(){
    window.location.href = 'https://goo.gl/maps/DYjYyvzdxfJUzdi48'
}
function mapswaze(){
    window.location.href = 'https://ul.waze.com/ul?place=Ej1SLiBSZWd1ZWlyYSBDb3N0YSAtIFJvc2FyaW5obywgUmVjaWZlIC0gUEUsIDUyMDQxLTA1MCwgQnJhemlsIi4qLAoUChIJ27Ju4lYYqwcR9E3qCasZq6sSFAoSCc9AtC9XGKsHEcv2dae8-CFA&ll=-8.03368190%2C-34.89836030&navigate=yes&utm_campaign=default&utm_source=waze_website&utm_medium=lm_share_location'
}
function uber(){
    window.location.href = 'https://m.uber.com/ul/?action=setPickup&client_id=56wiWyloFq7Iosr6uxSS1Wc_VOHNLSLd&pickup=my_location&dropoff[formatted_address]=Rua%20Regueira%20Costa%20-%20Rosarinho%2C%20Recife%20-%20PE%2C%20Brasil&dropoff[latitude]=-8.033682&dropoff[longitude]=-34.898360'
}

